import sqlite3

class Database:
    def __init__(self, db):
        self.con = sqlite3.connect(db)
        self.cur = self.con.cursor()
        sql = """
        CREATE TABLE IF NOT EXISTS employees(
            id INTEGER PRIMARY KEY,
            name TEXT,
            age TEXT,
            position TEXT,
            email TEXT,
            gender TEXT,
            contact TEXT,
            salary TEXT,
            address TEXT,
            attendance TEXT
        )
        """
        self.cur.execute(sql)
        self.con.commit()

    def insert(self, name, age, position, email, gender, contact, salary, address):
        self.cur.execute("INSERT INTO employees (name, age, position, email, gender, contact, salary, address, attendance) VALUES (?,?,?,?,?,?,?,?, 'Absent')",
                        (name, age, position, email, gender, contact, salary, address))
        self.con.commit()

    def fetch(self):
        self.cur.execute("SELECT * FROM employees")
        rows = self.cur.fetchall()
        return rows

    def remove(self, id):
        self.cur.execute("DELETE FROM employees WHERE id=?", (id,))
        self.con.commit()

    def update(self, id, name, age, position, email, gender, contact, salary, address):
        self.cur.execute(
            "UPDATE employees SET name=?, age=?, position=?, email=?, gender=?, contact=?, salary=?, address=? WHERE id=?",
            (name, age, position, email, gender, contact, salary, address, id))
        self.con.commit()

    def mark_attendance(self, id, status):
        self.cur.execute("UPDATE employees SET attendance=? WHERE id=?", (status, id))
        self.con.commit()

    def update_salary(self, id, new_salary):
        self.cur.execute("UPDATE employees SET salary=? WHERE id=?", (new_salary, id))
        self.con.commit()
